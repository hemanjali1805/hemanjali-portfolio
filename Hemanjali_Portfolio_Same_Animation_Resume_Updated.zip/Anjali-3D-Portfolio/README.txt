HEMANJALI PAIBOINA — 3D-INSPIRED PORTFOLIO

HOW TO OPEN
1. Extract this ZIP.
2. Open the extracted Anjali-3D-Portfolio folder.
3. Open index.html in a browser, or open the folder in VS Code and use Live Server.

ANIMATION AND DESIGN
- Preserves the original animated sunset scene, stars, parallax response, neon perspective grid, glass cards, scroll reveals, and responsive navigation.
- Portfolio content updated to match the attached resume.

RESUME DETAILS INCLUDED
- Computer Science and Engineering, SRKR Engineering College (2023–2027), CGPA 7.42
- Intermediate: 90.3%; Class 10: 98%
- Skills: Python, C, Java (Basic), HTML, CSS, JavaScript, React.js, Node.js, Express.js, SQL, MySQL, MongoDB, DBMS, Git, GitHub, VS Code, OOP, Advanced SQL, Tableau, ETL/data preparation, exploratory data analysis
- Lavish Bites full-stack food ordering website
- Sales Performance & Revenue Optimization Dashboard
- HACKSPRINT 24-hour hackathon, September 2025
- Strengths and career interests
- Actual LinkedIn and GitHub profile links

NOTE
Project buttons currently link to your GitHub profile because individual repository URLs were not supplied. Replace them with specific repository/demo URLs when available.
